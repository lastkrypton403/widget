# SGS III Weather Widget (native port of the Xwidget)

## Build without installing anything (GitHub)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder to the repository root (including the hidden .github folder).
3. Open the repo's Actions tab; the "Build APK" run starts by itself (or press Run workflow).
4. When it turns green (about 3-5 minutes), open the run and download the SGSIII-Weather-Widget-apk artifact. Unzip it to get app-debug.apk and install it.

## Or build locally
Open this folder in Android Studio -> Build > Build APK(s).

Then open the app once (grants location) and add the widget from the widget picker. Tap the widget to refresh.
