package com.sgs3.weatherwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.*;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.text.format.DateFormat;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Native re-creation of the "SGSIII+ Weather Widget Main" Xwidget (710x410 canvas, same coordinates). */
public class WeatherWidget extends BroadcastReceiver {
    static final String ACTION_TICK = "com.sgs3.weatherwidget.TICK";
    static final String ACTION_REFRESH = "com.sgs3.weatherwidget.REFRESH";
    static final String PREFS = "sgs3_weather";
    static final long STALE_MS = 30L * 60 * 1000;

    @Override
    public void onReceive(final Context ctx, final Intent intent) {
        final String action = intent.getAction();
        final boolean force = ACTION_REFRESH.equals(action);
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                long age = System.currentTimeMillis() - sp.getLong("updated", 0);
                if (force || age > STALE_MS) fetchWeather(ctx, sp);
                updateAll(ctx);
                scheduleNextTick(ctx);
            } catch (Throwable t) {
                t.printStackTrace();
            } finally {
                pr.finish();
            }
        }).start();
    }

    // ---------- scheduling ----------
    static void scheduleNextTick(Context ctx) {
        AppWidgetManager awm = AppWidgetManager.getInstance(ctx);
        int[] ids = awm.getAppWidgetIds(new ComponentName(ctx, WeatherWidget.class));
        if (ids.length == 0) return;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(ctx, WeatherWidget.class).setAction(ACTION_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long now = System.currentTimeMillis();
        long next = now - (now % 60000) + 60000;
        am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi);
    }

    // ---------- weather ----------
    static void fetchWeather(Context ctx, SharedPreferences sp) {
        double lat = Double.longBitsToDouble(sp.getLong("lat", Double.doubleToLongBits(23.1291)));  // Guangzhou default (as in original)
        double lon = Double.longBitsToDouble(sp.getLong("lon", Double.doubleToLongBits(113.2644)));
        try {
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) { lat = best.getLatitude(); lon = best.getLongitude(); }
        } catch (SecurityException ignored) { }
        boolean f = Locale.getDefault().getCountry().equals("US");
        try {
            String u = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                    + "&current=temperature_2m,weather_code,is_day&timezone=auto" + (f ? "&temperature_unit=fahrenheit" : "");
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(10000); c.setReadTimeout(10000);
            InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONObject cur = new JSONObject(bo.toString("UTF-8")).getJSONObject("current");
            int code = cur.getInt("weather_code");
            boolean day = cur.getInt("is_day") == 1;
            String city = "Current Location";
            try {
                List<Address> a = new Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1);
                if (a != null && !a.isEmpty()) {
                    Address ad = a.get(0);
                    if (ad.getLocality() != null) city = ad.getLocality();
                    else if (ad.getSubAdminArea() != null) city = ad.getSubAdminArea();
                    else if (ad.getAdminArea() != null) city = ad.getAdminArea();
                }
            } catch (Throwable ignored) { }
            sp.edit().putInt("temp", (int) Math.round(cur.getDouble("temperature_2m")))
                    .putInt("icon", toAccuIcon(code, day)).putString("cond", wmoText(code))
                    .putString("city", city).putString("unit", f ? "F" : "C")
                    .putLong("lat", Double.doubleToLongBits(lat)).putLong("lon", Double.doubleToLongBits(lon))
                    .putLong("updated", System.currentTimeMillis()).apply();
        } catch (Throwable t) {
            t.printStackTrace(); // keep last good data
        }
    }

    /** Open-Meteo WMO code -> AccuWeather icon number (the numbering used by wth/ and wth2/ folders). */
    static int toAccuIcon(int c, boolean day) {
        switch (c) {
            case 0: return day ? 1 : 33;
            case 1: return day ? 2 : 34;
            case 2: return day ? 3 : 35;
            case 3: return day ? 7 : 38;
            case 45: case 48: return 11;
            case 51: case 53: case 55: case 80: case 81: case 82: return day ? 12 : 40;
            case 56: case 57: case 66: case 67: return 26;
            case 61: case 63: case 65: return 18;
            case 71: case 73: case 75: case 77: case 85: case 86: return day ? 22 : 44;
            case 95: case 96: case 99: return day ? 15 : 42;
            default: return day ? 1 : 33;
        }
    }

    static String wmoText(int c) {
        switch (c) {
            case 0: return "Clear"; case 1: return "Mostly Clear"; case 2: return "Partly Cloudy"; case 3: return "Cloudy";
            case 45: case 48: return "Fog";
            case 51: case 53: case 55: return "Drizzle";
            case 56: case 57: case 66: case 67: return "Freezing Rain";
            case 61: case 63: case 65: return "Rain";
            case 71: case 73: case 75: case 77: return "Snow";
            case 80: case 81: case 82: return "Showers";
            case 85: case 86: return "Snow Showers";
            case 95: case 96: case 99: return "Thunderstorm";
            default: return "Clear";
        }
    }

    // ---------- rendering ----------
    static void updateAll(Context ctx) {
        AppWidgetManager awm = AppWidgetManager.getInstance(ctx);
        int[] ids = awm.getAppWidgetIds(new ComponentName(ctx, WeatherWidget.class));
        if (ids.length == 0) return;
        Bitmap bmp = render(ctx);
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget);
            rv.setImageViewBitmap(R.id.img, bmp);
            Intent i = new Intent(ctx, WeatherWidget.class).setAction(ACTION_REFRESH);
            rv.setOnClickPendingIntent(R.id.root, PendingIntent.getBroadcast(ctx, 2, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            awm.updateAppWidget(id, rv);
        }
    }

    static Bitmap asset(AssetManager am, String path) {
        try (InputStream in = am.open(path)) { return BitmapFactory.decodeStream(in); }
        catch (Exception e) { return null; }
    }

    static void img(Canvas c, Paint p, Bitmap b, float x, float y) { if (b != null) c.drawBitmap(b, x, y, p); }

    static void text(Canvas c, String s, Typeface tf, float size, int color, float x, float top, Paint.Align al, float shadowOpacity) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTypeface(tf); p.setTextSize(size); p.setColor(color); p.setTextAlign(al);
        p.setShadowLayer(2f, 2f, 2f, Color.argb((int) (255 * shadowOpacity), 0, 0, 0));
        c.drawText(s, x, top - p.ascent(), p);
    }

    static Bitmap render(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        AssetManager am = ctx.getAssets();
        int icon = sp.getInt("icon", 1);
        int temp = sp.getInt("temp", 0);
        String city = sp.getString("city", "Updating…");
        String cond = sp.getString("cond", "");
        String unit = sp.getString("unit", "C");
        long updated = sp.getLong("updated", 0);

        Bitmap out = Bitmap.createBitmap(710, 410, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        Typeface bold = Typeface.createFromAsset(am, "Roboto-Bold.ttf");
        Typeface reg = Typeface.createFromAsset(am, "Roboto-Regular.ttf");

        Calendar now = Calendar.getInstance();
        boolean h24 = DateFormat.is24HourFormat(ctx);
        int h = h24 ? now.get(Calendar.HOUR_OF_DAY) : (now.get(Calendar.HOUR) == 0 ? 12 : now.get(Calendar.HOUR));
        int m = now.get(Calendar.MINUTE);

        // Xwidget draws the first element on top, so paint bottom -> top (reverse of main.xul order).
        Bitmap bg = asset(am, "wth/" + icon + ".png");
        if (bg != null) c.drawBitmap(bg, null, new Rect(1, 5, 701, 405), bp);

        img(c, bp, asset(am, "num/" + (h / 10) + ".png"), 122, 49);   // h1
        img(c, bp, asset(am, "num/" + (h % 10) + ".png"), 223, 49);   // h2
        img(c, bp, asset(am, "time_dot.png"), 319, 49);               // dot
        img(c, bp, asset(am, "num/" + (m / 10) + ".png"), 367, 49);   // m1
        img(c, bp, asset(am, "num/" + (m % 10) + ".png"), 469, 49);   // m2

        if (!h24) text(c, now.get(Calendar.AM_PM) == Calendar.AM ? "AM" : "PM", reg, 45, Color.WHITE, 559, 127, Paint.Align.LEFT, .4f);

        Bitmap w2 = asset(am, "wth2/" + icon + ".png");               // small weather icon (box 188x120, scale .72, centred)
        if (w2 != null) {
            float bw = 188 * .72f, bh = 120 * .72f;
            float s = Math.min(bw / w2.getWidth(), bh / w2.getHeight());
            float dw = w2.getWidth() * s, dh = w2.getHeight() * s;
            float l = 539 + (188 - dw) / 2f, t = 198 + (120 - dh) / 2f;
            c.drawBitmap(w2, null, new RectF(l, t, l + dw, t + dh), bp);
        }

        img(c, bp, asset(am, "refresh.png"), 645, 357);

        String up = updated == 0 ? "--/-- --:--" :
                DateFormat.format(h24 ? "dd/MM HH:mm" : "dd/MM hh:mm a", updated).toString().toUpperCase(Locale.ROOT);
        text(c, up, reg, 25, Color.WHITE, 642, 353, Paint.Align.RIGHT, .4f);

        text(c, unit, reg, 48, Color.WHITE, 160, 306, Paint.Align.RIGHT, 1f);
        text(c, String.valueOf(temp), reg, 68, Color.WHITE, 122, 287, Paint.Align.RIGHT, .89f);
        text(c, cond, reg, 28, Color.WHITE, 684, 326, Paint.Align.RIGHT, 1f);
        text(c, city, bold, 28, Color.WHITE, 686, 290, Paint.Align.RIGHT, 1f);

        img(c, bp, asset(am, "temparature_icon.png"), 104, 299);      // degree sign
        img(c, bp, asset(am, "accuweather_logo.png"), 30, 364);
        img(c, bp, asset(am, "widget_hero_ic_current_location_small.png"), 585, 284);
        img(c, bp, asset(am, "weather_widget_emboss_night.png"), 5, 8);

        text(c, DateFormat.format("EEE, MMM d", now).toString(), bold, 37, Color.rgb(241, 245, 211), 255, 182, Paint.Align.LEFT, 1f);
        return out;
    }

}
