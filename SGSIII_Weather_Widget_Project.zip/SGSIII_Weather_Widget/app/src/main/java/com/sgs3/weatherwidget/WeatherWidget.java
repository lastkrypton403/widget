package com.sgs3.weatherwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.*;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Native re-creation of the "SGSIII+ Weather Widget Main" Xwidget (710x410 canvas, same coordinates). */
public class WeatherWidget extends BroadcastReceiver {
    static final String ACTION_TICK = "com.sgs3.weatherwidget.TICK";
    static final String ACTION_REFRESH = "com.sgs3.weatherwidget.REFRESH";
    static final String PREFS = "sgs3_weather";
    static final long STALE_MS = 30L * 60 * 1000;

    @Override
    public void onReceive(final Context ctx, final Intent intent) {
        final String action = intent.getAction();
        final boolean force = ACTION_REFRESH.equals(action);
        // Schedule the next minute tick FIRST so the chain can never break if the network fetch is slow or the process is killed.
        scheduleNextTick(ctx);
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                updateAll(ctx); // draw the clock instantly with cached weather
                long age = System.currentTimeMillis() - sp.getLong("updated", 0);
                if (force || age > STALE_MS) {
                    fetchWeather(ctx, sp);
                    updateAll(ctx);
                }
            } catch (Throwable t) {
                t.printStackTrace();
            } finally {
                pr.finish();
            }
        }).start();
    }

    // ---------- scheduling ----------
    static void scheduleNextTick(Context ctx) {
        AppWidgetManager awm = AppWidgetManager.getInstance(ctx);
        int[] ids = awm.getAppWidgetIds(new ComponentName(ctx, WeatherWidget.class));
        if (ids.length == 0) return;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(ctx, WeatherWidget.class).setAction(ACTION_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long now = System.currentTimeMillis();
        long next = now - (now % 60000) + 60000;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi);
            } else if (android.os.Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi);
            } else {
                am.setExact(AlarmManager.RTC, next, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi);
        }
    }

    // ---------- weather ----------
    static void fetchWeather(Context ctx, SharedPreferences sp) {
        double lat = Double.longBitsToDouble(sp.getLong("lat", Double.doubleToLongBits(23.1291)));  // Guangzhou default (as in original)
        double lon = Double.longBitsToDouble(sp.getLong("lon", Double.doubleToLongBits(113.2644)));
        try {
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) { lat = best.getLatitude(); lon = best.getLongitude(); }
        } catch (SecurityException ignored) { }
        try {
            String u = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                    + "&current=temperature_2m,weather_code,is_day&timezone=auto";
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(6000); c.setReadTimeout(6000);
            InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONObject cur = new JSONObject(bo.toString("UTF-8")).getJSONObject("current");
            int code = cur.getInt("weather_code");
            boolean day = cur.getInt("is_day") == 1;
            String city = "Current Location";
            try {
                List<Address> a = new Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 5);
                if (a != null && !a.isEmpty()) city = pickCity(a, city);
            } catch (Throwable ignored) { }
            sp.edit().putFloat("tempC", (float) cur.getDouble("temperature_2m"))
                    .putInt("icon", toAccuIcon(code, day)).putString("cond", wmoText(code))
                    .putString("city", city)
                    .putLong("lat", Double.doubleToLongBits(lat)).putLong("lon", Double.doubleToLongBits(lon))
                    .putLong("updated", System.currentTimeMillis()).apply();
        } catch (Throwable t) {
            t.printStackTrace(); // keep last good data
        }
    }

    static String cleanArea(String s) {
        if (s == null) return null;
        return s.replaceAll("(?i)\\s+(Governorate|Province|Prefecture|County|Region|District|Municipality|Metropolitan City)$", "").trim();
    }

    /** Short, AccuWeather-style city name: a long district name (e.g. "First 6th of October") falls back to the broader area ("Giza"). */
    static String pickCity(List<Address> list, String fallback) {
        String loc = null, adm = null, sub = null;
        for (Address ad : list) {
            if (loc == null && ad.getLocality() != null) loc = ad.getLocality();
            if (adm == null && ad.getAdminArea() != null) adm = cleanArea(ad.getAdminArea());
            if (sub == null && ad.getSubAdminArea() != null) sub = cleanArea(ad.getSubAdminArea());
        }
        String pick = loc;
        if (loc == null || loc.length() > 14) {
            for (String cand : new String[]{adm, sub}) {
                if (cand != null && !cand.isEmpty() && (loc == null || cand.length() < loc.length())) { pick = cand; break; }
            }
        }
        if (pick == null) return fallback;
        // still long? drop a leading ordinal word ("First 6th of October" -> "6th of October")
        if (pick.length() > 14) pick = pick.replaceFirst("(?i)^(first|second|third|fourth|fifth|1st|2nd|3rd)\\s+", "");
        return pick;
    }

    /** Open-Meteo WMO code -> AccuWeather icon number (the numbering used by wth/ and wth2/ folders). */
    static int toAccuIcon(int c, boolean day) {
        switch (c) {
            case 0: return day ? 1 : 33;
            case 1: return day ? 2 : 34;
            case 2: return day ? 3 : 35;
            case 3: return day ? 7 : 38;
            case 45: case 48: return 11;
            case 51: case 53: case 55: case 80: case 81: case 82: return day ? 12 : 40;
            case 56: case 57: case 66: case 67: return 26;
            case 61: case 63: case 65: return 18;
            case 71: case 73: case 75: case 77: case 85: case 86: return day ? 22 : 44;
            case 95: case 96: case 99: return day ? 15 : 42;
            default: return day ? 1 : 33;
        }
    }

    static String wmoText(int c) {
        switch (c) {
            case 0: return "Clear"; case 1: return "Mostly Clear"; case 2: return "Partly Cloudy"; case 3: return "Cloudy";
            case 45: case 48: return "Fog";
            case 51: case 53: case 55: return "Drizzle";
            case 56: case 57: case 66: case 67: return "Freezing Rain";
            case 61: case 63: case 65: return "Rain";
            case 71: case 73: case 75: case 77: return "Snow";
            case 80: case 81: case 82: return "Showers";
            case 85: case 86: return "Snow Showers";
            case 95: case 96: case 99: return "Thunderstorm";
            default: return "Clear";
        }
    }

    // ---------- rendering ----------
    static void updateAll(Context ctx) {
        AppWidgetManager awm = AppWidgetManager.getInstance(ctx);
        int[] ids = awm.getAppWidgetIds(new ComponentName(ctx, WeatherWidget.class));
        if (ids.length == 0) return;
        Bitmap bmp = render(ctx);
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget);
            rv.setImageViewBitmap(R.id.img, bmp);
            Intent i = new Intent(ctx, WeatherWidget.class).setAction(ACTION_REFRESH);
            rv.setOnClickPendingIntent(R.id.root, PendingIntent.getBroadcast(ctx, 2, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            awm.updateAppWidget(id, rv);
        }
    }

    static Bitmap asset(AssetManager am, String path) {
        try (InputStream in = am.open(path)) { return BitmapFactory.decodeStream(in); }
        catch (Exception e) { return null; }
    }

    static void img(Canvas c, Paint p, Bitmap b, float x, float y) { if (b != null) c.drawBitmap(b, x, y, p); }

    static void text(Canvas c, String s, Typeface tf, float size, int color, float x, float top, Paint.Align al, float shadowOpacity) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTypeface(tf); p.setTextSize(size); p.setColor(color); p.setTextAlign(al);
        p.setShadowLayer(2f, 2f, 2f, Color.argb((int) (255 * shadowOpacity), 0, 0, 0));
        c.drawText(s, x, top - p.ascent(), p);
    }

    static void textBase(Canvas c, String s, Typeface tf, float size, int color, float x, float baseline, Paint.Align al, float shadowOpacity) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTypeface(tf); p.setTextSize(size); p.setColor(color); p.setTextAlign(al);
        p.setShadowLayer(2f, 2f, 2f, Color.argb((int) (255 * shadowOpacity), 0, 0, 0));
        c.drawText(s, x, baseline, p);
    }

    static Bitmap render(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        AssetManager am = ctx.getAssets();
        int icon = sp.getInt("icon", 1);
        String pref = sp.getString("unit_pref", "AUTO");
        boolean useF = pref.equals("F") || (pref.equals("AUTO") && Locale.getDefault().getCountry().equals("US"));
        float tc = sp.getFloat("tempC", 0f);
        int temp = Math.round(useF ? tc * 9f / 5f + 32f : tc);
        String city = sp.getString("city", "Updating…");
        String cond = sp.getString("cond", "");
        String unit = useF ? "F" : "C";
        long updated = sp.getLong("updated", 0);

        Bitmap out = Bitmap.createBitmap(710, 410, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        Typeface bold = Typeface.createFromAsset(am, "Roboto-Bold.ttf");
        Typeface reg = Typeface.createFromAsset(am, "Roboto-Regular.ttf");
        Typeface light = Typeface.create("sans-serif-light", Typeface.NORMAL);
        Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);

        Calendar now = Calendar.getInstance();
        String cpref = sp.getString("clock_pref", "AUTO");
        boolean h24 = cpref.equals("24") || (cpref.equals("AUTO") && DateFormat.is24HourFormat(ctx));
        int h = h24 ? now.get(Calendar.HOUR_OF_DAY) : (now.get(Calendar.HOUR) == 0 ? 12 : now.get(Calendar.HOUR));
        int m = now.get(Calendar.MINUTE);

        // Xwidget draws the first element on top, so paint bottom -> top (reverse of main.xul order).
        Bitmap bg = asset(am, "wth/" + icon + ".png");
        if (bg != null) c.drawBitmap(bg, null, new Rect(1, 5, 701, 405), bp);

        // Clock group is centred (12h mode drops the leading zero, so a one-digit hour makes a 3-glyph group).
        boolean twoDigitHour = h24 || h >= 10;
        float off = 0, h2off = 101, dotOff, m1Off, m2Off;
        if (twoDigitHour) { dotOff = 197; m1Off = 245; m2Off = 347; }
        else { dotOff = 96; m1Off = 144; m2Off = 246; }
        float total = m2Off + 102;
        float left = 346 - total / 2f;
        if (twoDigitHour) {
            img(c, bp, asset(am, "num/" + (h / 10) + ".png"), left, 49);
            img(c, bp, asset(am, "num/" + (h % 10) + ".png"), left + h2off, 49);
        } else {
            img(c, bp, asset(am, "num/" + h + ".png"), left, 49);
        }
        img(c, bp, asset(am, "time_dot.png"), left + dotOff, 49);
        img(c, bp, asset(am, "num/" + (m / 10) + ".png"), left + m1Off, 49);
        img(c, bp, asset(am, "num/" + (m % 10) + ".png"), left + m2Off, 49);

        if (!h24) textBase(c, now.get(Calendar.AM_PM) == Calendar.AM ? "AM" : "PM", reg, 45,
                Color.argb(220, 255, 255, 255), left + m2Off + 102 + 4, 167, Paint.Align.LEFT, .4f);

        Bitmap w2 = asset(am, "wth2/" + icon + ".png");               // small weather icon, native size
        if (w2 != null) {
            float sc = 1.5f, dw = w2.getWidth() * sc, dh = w2.getHeight() * sc;
            float cx = 620, cy = 236;
            c.drawBitmap(w2, null, new RectF(cx - dw / 2f, cy - dh / 2f, cx + dw / 2f, cy + dh / 2f), bp);
        }

        img(c, bp, asset(am, "refresh.png"), 645, 357);

        String up = updated == 0 ? "--/-- --:--" :
                DateFormat.format(h24 ? "dd/MM HH:mm" : "dd/MM hh:mm a", updated).toString().toUpperCase(Locale.ROOT);
        text(c, up, light, 25, Color.argb(190, 255, 255, 255), 642, 361, Paint.Align.RIGHT, .3f);

        // --- temperature group: thin number, small degree sign hugging it, then unit ---
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        tp.setTypeface(light); tp.setTextSize(68);
        String ts = String.valueOf(temp);
        float numLeft = 29;
        float numRight = numLeft + tp.measureText(ts);
        float baseline = 273 - tp.ascent();
        float capTop = baseline - 0.711f * 68;
        textBase(c, ts, light, 68, Color.WHITE, numLeft, baseline, Paint.Align.LEFT, .89f);
        Bitmap deg = asset(am, "temparature_icon.png");
        float degX = numRight + 2;
        if (deg != null) c.drawBitmap(deg, null, new RectF(degX, capTop - 1, degX + 16, capTop - 1 + 14), bp);
        textBase(c, unit, light, 48, Color.WHITE, degX + 16 + 1, baseline, Paint.Align.LEFT, 1f);

        img(c, bp, asset(am, "accuweather_logo.png"), 30, 364);

        // --- condition + city (city shrinks to fit; pin sits just left of the text) ---
        text(c, cond, reg, 28, Color.WHITE, 684, 326, Paint.Align.RIGHT, 1f);
        float pin = 32, gap = 10, maxW = 290 - pin - gap;
        Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        cp.setTypeface(medium);
        float csize = 28;
        cp.setTextSize(csize);
        while (csize > 18 && cp.measureText(city) > maxW) { csize -= 1; cp.setTextSize(csize); }
        city = TextUtils.ellipsize(city, new TextPaint(cp), maxW, TextUtils.TruncateAt.END).toString();
        float cw = cp.measureText(city);
        text(c, city, medium, csize, Color.WHITE, 686, 290 + (28 - csize) / 2f, Paint.Align.RIGHT, 1f);
        img(c, bp, asset(am, "widget_hero_ic_current_location_small.png"), 686 - cw - gap - pin, 291);
        img(c, bp, asset(am, "weather_widget_emboss_night.png"), 5, 8);

        text(c, DateFormat.format("EEE, MMM d", now).toString(), bold, 37, Color.rgb(241, 245, 211), 350, 182, Paint.Align.CENTER, 1f);
        return out;
    }

}
