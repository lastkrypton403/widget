package com.sgs3.weatherwidget;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    private TextView status;
    private LinearLayout results;
    private EditText search;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 96, 48, 96);
        scroll.addView(root);

        root.addView(label("SGS III Weather Widget\n\nAdd the widget from your home screen's widget picker. Tap the widget to refresh.", 18, 0));

        root.addView(label("Temperature unit:", 18, 32));
        root.addView(prefButton("Celsius (°C)", "unit_pref", "C"));
        root.addView(prefButton("Fahrenheit (°F)", "unit_pref", "F"));
        root.addView(prefButton("Automatic (by phone region)", "unit_pref", "AUTO"));

        root.addView(label("Clock format:", 18, 32));
        root.addView(prefButton("12-hour (with AM/PM)", "clock_pref", "12"));
        root.addView(prefButton("24-hour", "clock_pref", "24"));
        root.addView(prefButton("Automatic (phone setting)", "clock_pref", "AUTO"));

        root.addView(label("Location:", 18, 32));
        Button gps = new Button(this);
        gps.setText("Use my current location");
        gps.setOnClickListener(v -> {
            prefs().edit().putString("loc_mode", "AUTO").apply();
            showStatus();
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            else sendRefresh();
        });
        root.addView(gps);

        search = new EditText(this);
        search.setHint("Or search for a city…");
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v, actionId, ev) -> { doSearch(); return true; });
        root.addView(search);

        Button go = new Button(this);
        go.setText("Search");
        go.setOnClickListener(v -> doSearch());
        root.addView(go);

        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);

        status = label("", 16, 32);
        root.addView(status);
        setContentView(scroll);
        showStatus();

        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        else sendRefresh();
    }

    private TextView label(String text, int size, int topPad) {
        TextView t = new TextView(this);
        t.setTextSize(size);
        t.setPadding(0, topPad, 0, 0);
        t.setText(text);
        return t;
    }

    private SharedPreferences prefs() { return getSharedPreferences(WeatherWidget.PREFS, MODE_PRIVATE); }

    private Button prefButton(String label, final String key, final String value) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setOnClickListener(v -> {
            prefs().edit().putString(key, value).apply();
            showStatus();
            sendBroadcast(new Intent(this, WeatherWidget.class).setAction(WeatherWidget.ACTION_TICK));
        });
        return btn;
    }

    private void doSearch() {
        final String q = search.getText().toString().trim();
        if (q.isEmpty()) return;
        results.removeAllViews();
        results.addView(label("Searching…", 16, 8));
        new Thread(() -> {
            try {
                String u = "https://geocoding-api.open-meteo.com/v1/search?count=6&language=en&format=json&name=" + URLEncoder.encode(q, "UTF-8");
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(8000);
                InputStream in = c.getInputStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096]; int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                JSONObject root = new JSONObject(bo.toString("UTF-8"));
                final JSONArray arr = root.optJSONArray("results");
                runOnUiThread(() -> showResults(arr));
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    results.removeAllViews();
                    results.addView(label("Search failed. Check your connection and try again.", 16, 8));
                });
            }
        }).start();
    }

    private void showResults(JSONArray arr) {
        results.removeAllViews();
        if (arr == null || arr.length() == 0) {
            results.addView(label("No matches found.", 16, 8));
            return;
        }
        for (int i = 0; i < arr.length(); i++) {
            final JSONObject r = arr.optJSONObject(i);
            if (r == null) continue;
            final String name = r.optString("name");
            String admin = r.optString("admin1", "");
            String cc = r.optString("country_code", "");
            String text = name + (admin.isEmpty() ? "" : ", " + admin) + (cc.isEmpty() ? "" : ", " + cc);
            final double lat = r.optDouble("latitude"), lon = r.optDouble("longitude");
            Button btn = new Button(this);
            btn.setAllCaps(false);
            btn.setText(text);
            btn.setOnClickListener(v -> {
                prefs().edit().putString("loc_mode", "MANUAL")
                        .putString("man_lat", String.valueOf(lat)).putString("man_lon", String.valueOf(lon))
                        .putString("man_name", name).apply();
                results.removeAllViews();
                showStatus();
                Toast.makeText(this, "Location set to " + name, Toast.LENGTH_SHORT).show();
                sendRefresh();
            });
            results.addView(btn);
        }
    }

    private void showStatus() {
        SharedPreferences sp = prefs();
        String p = sp.getString("unit_pref", "AUTO");
        String cp = sp.getString("clock_pref", "AUTO");
        boolean manual = sp.getString("loc_mode", "AUTO").equals("MANUAL");
        status.setText("Unit: " + (p.equals("C") ? "Celsius" : p.equals("F") ? "Fahrenheit" : "Automatic")
                + "\nClock: " + (cp.equals("12") ? "12-hour" : cp.equals("24") ? "24-hour" : "Automatic")
                + "\nLocation: " + (manual ? sp.getString("man_name", "Custom") : "Current location"));
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { sendRefresh(); }

    private void sendRefresh() {
        sendBroadcast(new Intent(this, WeatherWidget.class).setAction(WeatherWidget.ACTION_REFRESH));
    }
}
