package com.sgs3.weatherwidget;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 96, 48, 48);

        TextView t = new TextView(this);
        t.setTextSize(18);
        t.setText("SGS III Weather Widget\n\nGrant location permission for local weather, then add the widget from your home screen's widget picker. Tap the widget to refresh.\n\nTemperature unit:");
        root.addView(t);

        root.addView(unitButton("Celsius (°C)", "C"));
        root.addView(unitButton("Fahrenheit (°F)", "F"));
        root.addView(unitButton("Automatic (by phone region)", "AUTO"));

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 32, 0, 0);
        root.addView(status);
        setContentView(root);
        showStatus();

        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        else sendRefresh();
    }

    private Button unitButton(String label, final String value) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                getSharedPreferences(WeatherWidget.PREFS, MODE_PRIVATE).edit().putString("unit_pref", value).apply();
                showStatus();
                sendBroadcast(new Intent(MainActivity.this, WeatherWidget.class).setAction(WeatherWidget.ACTION_TICK));
            }
        });
        return btn;
    }

    private void showStatus() {
        SharedPreferences sp = getSharedPreferences(WeatherWidget.PREFS, MODE_PRIVATE);
        String p = sp.getString("unit_pref", "AUTO");
        status.setText("Current setting: " + (p.equals("C") ? "Celsius" : p.equals("F") ? "Fahrenheit" : "Automatic"));
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { sendRefresh(); }

    private void sendRefresh() {
        sendBroadcast(new Intent(this, WeatherWidget.class).setAction(WeatherWidget.ACTION_REFRESH));
    }
}
