package com.sgs3.weatherwidget;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setPadding(48, 96, 48, 48); t.setTextSize(18);
        t.setText("SGS III Weather Widget\n\nGrant location permission (for local weather), then add the widget from your home screen's widget picker. Tap the widget to refresh.");
        setContentView(t);
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        else sendRefresh();
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { sendRefresh(); }
    private void sendRefresh() { sendBroadcast(new Intent(this, WeatherWidget.class).setAction(WeatherWidget.ACTION_REFRESH)); }
}
