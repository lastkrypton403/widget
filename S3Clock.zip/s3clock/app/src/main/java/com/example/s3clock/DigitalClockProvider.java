package com.example.s3clock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.AlarmClock;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Samsung Galaxy S3 style digital clock widget, rebuilt as a native AppWidget. */
public class DigitalClockProvider extends AppWidgetProvider {

    private static final String ACTION_TICK = "com.example.s3clock.TICK";

    private static final int[] DIGITS = {
            R.drawable.digit_0, R.drawable.digit_1, R.drawable.digit_2, R.drawable.digit_3,
            R.drawable.digit_4, R.drawable.digit_5, R.drawable.digit_6, R.drawable.digit_7,
            R.drawable.digit_8, R.drawable.digit_9
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent); // handles APPWIDGET_UPDATE -> onUpdate
        String action = intent.getAction();
        if (action == null || AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(action)) return;

        // Tick, time/zone/locale change, boot, or app update: redraw and re-arm.
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(context, DigitalClockProvider.class));
        if (ids.length == 0) {
            cancelTick(context);
            return;
        }
        render(context, mgr, ids);
        scheduleNextTick(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        render(context, mgr, ids);
        scheduleNextTick(context);
    }

    @Override
    public void onEnabled(Context context) {
        scheduleNextTick(context);
    }

    @Override
    public void onDisabled(Context context) {
        cancelTick(context);
    }

    // ---------------------------------------------------------------- drawing

    private static void render(Context ctx, AppWidgetManager mgr, int[] ids) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_clock);

        boolean h24 = DateFormat.is24HourFormat(ctx);
        Calendar now = Calendar.getInstance();
        int hour = now.get(h24 ? Calendar.HOUR_OF_DAY : Calendar.HOUR);
        if (!h24 && hour == 0) hour = 12;
        int minute = now.get(Calendar.MINUTE);

        // Original hides the leading hour digit in 12h mode (e.g. " 9:05").
        if (!h24 && hour < 10) {
            rv.setViewVisibility(R.id.hour_1, View.GONE);
        } else {
            rv.setViewVisibility(R.id.hour_1, View.VISIBLE);
            rv.setImageViewResource(R.id.hour_1, DIGITS[hour / 10]);
        }
        rv.setImageViewResource(R.id.hour_2, DIGITS[hour % 10]);
        rv.setImageViewResource(R.id.colon, R.drawable.digit_colon);
        rv.setImageViewResource(R.id.minute_1, DIGITS[minute / 10]);
        rv.setImageViewResource(R.id.minute_2, DIGITS[minute % 10]);

        if (h24) {
            rv.setViewVisibility(R.id.ampm, View.GONE);
        } else {
            rv.setViewVisibility(R.id.ampm, View.VISIBLE);
            rv.setImageViewResource(R.id.ampm,
                    now.get(Calendar.AM_PM) == Calendar.AM ? R.drawable.ampm_am : R.drawable.ampm_pm);
        }

        Locale loc = Locale.getDefault();
        Date d = now.getTime();
        String day = new SimpleDateFormat(DateFormat.getBestDateTimePattern(loc, "EEE"), loc).format(d);
        if ("en".equals(loc.getLanguage())) day += ".";
        String date = new SimpleDateFormat(DateFormat.getBestDateTimePattern(loc, "dMMM"), loc).format(d);
        rv.setTextViewText(R.id.day_text, day);
        rv.setTextViewText(R.id.date_text, date);

        String spoken = DateFormat.format(h24 ? "HH:mm" : "h:mm a", now).toString();
        rv.setContentDescription(R.id.time_group, spoken);

        // Tap opens the clock / alarms app.
        Intent open = new Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.root, pi);

        mgr.updateAppWidget(ids, rv);
    }

    // ------------------------------------------------------------- scheduling

    private static PendingIntent tickIntent(Context ctx) {
        Intent i = new Intent(ctx, DigitalClockProvider.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(ctx, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void scheduleNextTick(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long next = (System.currentTimeMillis() / 60000L + 1) * 60000L;
        PendingIntent pi = tickIntent(ctx);
        boolean exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
        try {
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi); // may drift a bit
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi);
        }
    }

    private static void cancelTick(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(tickIntent(ctx));
    }
}
