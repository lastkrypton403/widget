# S3 Digital Clock widget

Native AppWidget rebuild of the Galaxy S3 (TouchWiz) "single digital clock" widget.
Artwork (digits, AM/PM, background) comes from the original widget package; the
logic is new, so it needs no Samsung framework or Xwidget.

Build: open in Android Studio and run, or push to GitHub and download the APK
from Actions -> Build APK -> Artifacts. Then long-press the home screen -> Widgets ->
"Digital clock (S3)".

Notes
- Updates every minute via exact alarms. On Android 12/12L you may need to allow
  "Alarms & reminders" for it, otherwise it may drift a few minutes.
- 12h/24h follows the system setting. Tap opens your clock app.
- Samsung's artwork is copyrighted: keep that in mind if you publish.
